import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

// Create the context
export const AuthContext = createContext();
// Create a provider component
const ipcRenderer = window.ipcRenderer;
export const AuthProvider = ({ children }) => {
  //Main State
  const [allfamily, setAllFamily] = useState(null);
  const [allkariyas, setAllKariyas] = useState(null);
  const [allmohalla, setAllMohalla] = useState(null);
  const [population, setPopulation] = useState(null);
  const [admin, setAdmin] = useState(null);
  const [loading, setLoading] = useState(true); // Loading state to track login check
  const [isLoggedIn, setIsLoggedIn] = useState(false); // State to track login status
  const [isLoading, setIsLoading] = useState(true); // Track loading state

  const [folderPath, setfolderPath] = useState("");
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [toastMessage, setShowToastMessage] = useState("");
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    function updateOnlineStatus() {
      const online = navigator.onLine;
      setIsOnline(online);

      if (!online) {
        // Show offline toast immediately
        setShowToastMessage("No Internet Connection");
        setShowToast(true);
      } else {
        // Show connected toast, then hide after 2 seconds
        setShowToastMessage("Connected to Network");
        setShowToast(true);

        setTimeout(() => {
          setShowToast(false);
        }, 2000);
      }
    }

    window.addEventListener("online", updateOnlineStatus);
    window.addEventListener("offline", updateOnlineStatus);

    // Call once to initialize
    updateOnlineStatus();

    return () => {
      window.removeEventListener("online", updateOnlineStatus);
      window.removeEventListener("offline", updateOnlineStatus);
    };
  }, []);
  const loadAdminDetail = async () => {
    if (ipcRenderer) {
      try {
        // Get desktop folder path dynamically here
        const appFolder = await ipcRenderer.invoke("get-app-folder");
        await setfolderPath(appFolder);
        // const token = JSON.parse(localStorage.getItem("Token"));
        const token = await ipcRenderer.invoke("get-token");
        const response = await ipcRenderer.invoke("getAdmin", token);
        let adminDetail = response?.admin;
        await localStorage.setItem("admin", JSON.stringify(adminDetail));
        await setAdmin(adminDetail);
      } catch (error) {
        console.error("Error invoking get-data:", error);
      }
    } else {
      console.error("ipcRenderer is not defined");
    }
  };

  const saveToFile = async (fileName, data) => {
    try {
      const savedRes = await ipcRenderer.invoke("save-json", {
        fileName,
        data,
      });
    } catch (err) {
      console.error("Error saving JSON:", err);
    }
  };
  const [isLoadingFamily, setIsLoadingFamily] = useState(true);
  const [isLoadingKariyas, setIsLoadingKariyas] = useState(true);
  const [isLoadingMohalla, setIsLoadingMohalla] = useState(true);
  const [isLoadingPopulation, setIsLoadingPopulation] = useState(true);
  const [syncing, setSyncing] = useState(true);
  const [addedNew, setAddedNew] = useState(false);
  const [isFileExist, setIsFileExist] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const [dbConnected, setDbConnected] = useState(false);
  const [retry, setRetry] = useState(0);

  const checkDBConnection = async () => {
    try {
      const connectionStatus = await ipcRenderer.invoke("dbconnection");
      return connectionStatus; // Ensure we return the result to be used
    } catch (error) {
      console.error("Error checking connection:", error);
      return { success: false, message: "Error occurred" }; // Return an error response
    }
  };
  useEffect(() => {
    const fetchConnectionStatus = async () => {
      const connectionResponse = await checkDBConnection(); // Wait for the async function to finish
      setDbConnected(connectionResponse.success); // Update state after fetching data
    };
    fetchConnectionStatus(); // Call the async function inside the useEffect
  }, []); // Only run on mount

  useEffect(() => {
    // if (isLoggedIn) {
    loadAdminDetail();
    setIsLoading(false);
    // }
  }, [isLoggedIn, dbConnected]);

  const [mohallaDetail, setMohallaDetail] = useState(allmohalla || {}); // Initialize with an empty object if allmohalla is null or undefined

  // Generic function to load data
  const loadData = async (
    key,
    apiMethod,
    setState,
    setLoading,
    fromLocal = true
  ) => {
    setLoading(true);
    try {
      const data =
        !isFileExist && fromLocal
          ? await loadStoredData(key)
          : await ipcRenderer.invoke(apiMethod).then((response) => {
              if (response?.success) {
                console.log("Getting From Database...", key);
                saveToFile(key, response[Object.keys(response)[2]]); // Save fresh data locally
                return response[Object.keys(response)[2]];
              }
              return null;
            });
      setState(data);
    } catch (error) {
      console.error(`Error loading ${key}:`, error);
    } finally {
      setLoading(false);
    }
  };

  // Function to sync data if `local-insert.json` exists

  // Function to sync data if `local-insert.json` exists
  const SyncData = async (fromhomepage) => {
    if (!isOnline) {
      setSyncing(false);
      console.log("No internet connection. Unable to sync.");
      return;
    }

    try {
      if (fromhomepage) {
        setSyncing(true);
        try {
          await loadFreshData();
        } catch (error) {
          console.error("Error loading fresh data from homepage:", error);
        } finally {
          setSyncing(false);
        }
        return;
      }

      // Normal sync flow
      // setSyncing(true);
      const uploadRes = await ipcRenderer.invoke("sync-local-data");
      if (uploadRes.success) {
        await loadFreshData();
      }
    } catch (error) {
      console.error("Error during sync:", error);
    } finally {
      setSyncing(false);
    }
  };

  // Load fresh data from the database
  const loadFreshData = async () => {
    console.log("Loading fresh data from the database...");
    const keys = [
      { key: "familyDetail", apiMethod: "getallfamily", setter: setAllFamily },
      { key: "kariyaDetail", apiMethod: "getkariyas", setter: setAllKariyas },
      { key: "mohallaDetail", apiMethod: "getmohallas", setter: setAllMohalla },
      { key: "Population", apiMethod: "getallmember", setter: setPopulation },
    ];
    for (const { key, apiMethod, setter } of keys) {
      await loadData(key, apiMethod, setter, () => {}, false); // Load fresh data and save it locally
    }
  };

  // Function to check if files exist locally
  const checkLocalFiles = async (fileNames) => {
    try {
      const response = await ipcRenderer.invoke("check-local-file", fileNames);
      if (response.success) {
        const files = response.files.map((file) => ({
          fileName: file.fileName,
          exists: file.exists,
          filePath: file.filePath,
        }));
        return files;
      } else {
        console.error("Error:", response.message);
        return [];
      }
    } catch (error) {
      console.error("Error checking files:", error);
      return [];
    }
  };

  // Function to load one file locally or from server if missing locally
  const loadFile = async (fileName, apiEndpoint, setData, setLoading) => {
    const files = await checkLocalFiles([fileName + ".json"]);
    const fileExists = files.some(
      (file) => file.fileName === fileName + ".json" && file.exists
    );
    if (fileExists) {
      const localData = await loadStoredData(fileName);
      setData(localData);
    } else {
      await loadData(fileName, apiEndpoint, setData, setLoading);
    }
  };
  // Load all files locally without network calls (for offline)
  const loadAllLocalData = async () => {
    const localFamilyDetail = await loadStoredData("familyDetail");
    setAllFamily(localFamilyDetail);
    const localKariyaDetail = await loadStoredData("kariyaDetail");
    setAllKariyas(localKariyaDetail);
    const localMohallaDetail = await loadStoredData("mohallaDetail");
    setAllMohalla(localMohallaDetail);
    const localPopulation = await loadStoredData("Population");
    setPopulation(localPopulation);
  };
  useEffect(() => {
    const initializeSync = async () => {
      if (isOnline && dbConnected && isLoggedIn) {
        if (addedNew) {
          console.log("New data added, fetching fresh data...");
          setSyncing(true);
          await loadFreshData();
          setSyncing(false);

          return;
        }
        const filesExist = await checkLocalFiles(["local-insert.json"]);
        if (
          filesExist.some(
            (file) => file.fileName === "local-insert.json" && file.exists
          )
        ) {
          console.log("local-insert.json found, starting sync...");
          setSyncing(true);
          await SyncData();
        } else {
          const requiredFiles = [
            {
              fileName: "familyDetail",
              api: "getallfamily",
              setter: setAllFamily,
              loadingSetter: setIsLoadingFamily,
            },
            {
              fileName: "kariyaDetail",
              api: "getkariyas",
              setter: setAllKariyas,
              loadingSetter: setIsLoadingKariyas,
            },
            {
              fileName: "mohallaDetail",
              api: "getmohallas",
              setter: setAllMohalla,
              loadingSetter: setIsLoadingMohalla,
            },
            {
              fileName: "Population",
              api: "getallmember",
              setter: setPopulation,
              loadingSetter: setIsLoadingPopulation,
            },
          ];

          const files = await checkLocalFiles(
            requiredFiles.map((f) => f.fileName + ".json")
          );

          // If any required file exists locally, load individually with fallback to server
          if (files.some((file) => file.exists)) {
            for (const f of requiredFiles) {
              await loadFile(f.fileName, f.api, f.setter, f.loadingSetter);
            }
          } else {
            setSyncing(true);
            console.log("Files missing locally, fetching fresh data...");
            await loadFreshData();
            setSyncing(false);
          }
        }
      } else {
        if (!isOnline) {
          // Offline or DB disconnected → load all from local storage directly
          console.log("Offline or DB disconnected, loading from local only...");
          await loadAllLocalData();
        }
      }
    };
    initializeSync();
  }, [isOnline, dbConnected, isFileExist, addedNew, retry, isLoggedIn]);

  useEffect(() => {
    // Handle the syncing state based on file existence
    if (!isFileExist) {
      setSyncing(false); // No sync needed if files don't exist
    }
  }, [isFileExist]);

  // Function to load data from local storage
  const loadStoredData = async (fileName) => {
    try {
      const storedData = await ipcRenderer.invoke("get-json", { fileName });
      let ResStatus = storedData?.success;
      let ResData = storedData?.parsedData;
      if (ResStatus) {
        // console.log(`Getting ${fileName} from local storage...`);
        return ResData || null;
      } else {
        // console.error(`${fileName} not found in local storage.`);
        return null;
      }
    } catch (error) {
      console.error("Error loading JSON:", error);
      return null;
    }
  };

  // const { darkMode } = useGlobalTheme();

  // const TableStyles = {
  //   fontFamily: "Poppins",
  //   fontSize: 15,
  //   color: darkMode ? "white" : "black",
  //   borderColor: darkMode ? "gray" : "black",
  //   // textAlign: "center",
  // };

  const handleRetry = () => {
    setRetry((prev) => prev + 1);
  };

  // Add these functions inside your AuthProvider component

  const deleteAllData = async () => {
    try {
      const result = await ipcRenderer.invoke("delete-all-data");

      if (result.success) {
        // Clear local state
        setAllFamily(null);
        setAllKariyas(null);
        setAllMohalla(null);
        setPopulation(null);
        setAdmin(null);
        setIsLoggedIn(false);

        // Clear localStorage
        localStorage.clear();

        setShowToastMessage("All data deleted successfully");
        setShowToast(true);

        console.log("✅ Deleted files:", result.deletedFiles);
      } else {
        setShowToastMessage("Failed to delete some files");
        setShowToast(true);
        console.error("Errors:", result.errors);
      }

      return result;
    } catch (error) {
      console.error("Error deleting all data:", error);
      setShowToastMessage("Error deleting data");
      setShowToast(true);
      return { success: false, error: error.message };
    }
  };

  const deleteAllImages = async () => {
    try {
      const result = await ipcRenderer.invoke("delete-all-images");

      if (result.success) {
        setShowToastMessage(`Deleted ${result.totalFilesDeleted} image files`);
        setShowToast(true);
        console.log("✅ Deleted folders:", result.deletedFolders);
      } else {
        setShowToastMessage("Failed to delete some images");
        setShowToast(true);
        console.error("Errors:", result.errors);
      }

      return result;
    } catch (error) {
      console.error("Error deleting images:", error);
      setShowToastMessage("Error deleting images");
      setShowToast(true);
      return { success: false, error: error.message };
    }
  };

  const getStorageStats = async () => {
    try {
      const result = await ipcRenderer.invoke("get-storage-stats");
      return result;
    } catch (error) {
      console.error("Error getting storage stats:", error);
      return { success: false, error: error.message };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isOnline,
        admin,
        loading,
        setLoading,
        isLoggedIn,
        setIsLoggedIn,
        // Main State
        allfamily,
        setAllFamily,
        allkariyas,
        allmohalla,
        setAllMohalla,
        population,
        setPopulation,
        mohallaDetail,
        setMohallaDetail,
        isLoading,
        syncing,
        setAddedNew,
        folderPath,
        getSanitizedLocalFilePathSync,
        // TableStyles,
        handleRetry,
        showToast,
        setShowToast,
        toastMessage,
        SyncData,
        loadFreshData,
        deleteAllData,
        deleteAllImages,
        getStorageStats,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
export const useGlobalContext = () => useContext(AuthContext);

export const getSanitizedLocalFilePathSync = (url, localFolder) => {
  try {
    if (!url) return null;

    // Check if already a local path (starts with "/Users" or "C:\\" or similar)
    if (
      url.startsWith("/") ||
      url.startsWith("C:\\") ||
      url.startsWith("file://")
    ) {
      const localPath = url.startsWith("file://")
        ? url.replace("file://", "")
        : url;

      const exists = window.ipcRenderer.sendSync(
        "check-file-exists-sync",
        localPath
      );

      return exists ? `file://${localPath}` : null;
    }

    // Cloudinary-style URL handling
    if (!localFolder) return url;

    const relativePath = new URL(url).pathname.split("/upload/")[1];
    if (!relativePath) return url;

    const sanitizedFileName = relativePath.replace(/\//g, "_");
    const fullLocalPath = `${localFolder}/${sanitizedFileName}`;

    const fileExists = window.ipcRenderer.sendSync(
      "check-file-exists-sync",
      fullLocalPath
    );

    return fileExists ? `file://${fullLocalPath}` : url;
  } catch (err) {
    console.error("Invalid path or URL:", err);
    return null;
  }
};
