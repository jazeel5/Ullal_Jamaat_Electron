const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    // await mongoose.connect("mongodb+srv://jazeel5:Admin@cluster0.oud0fml.mongodb.net/ejamaat");
    await mongoose.connect("mongodb+srv://jazeel5:Admin@cluster0.oud0fml.mongodb.net/E-jamaat2");
    console.log("MongoDB connected successfully");
  } catch (err) {
    console.error("Failed to connect to MongoDB:", err);
    // process.exit(1); // Exit the process on connection failure
  }
};
module.exports = connectDB;
