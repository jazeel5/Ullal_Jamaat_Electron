import React from "react";
import { Card, CardContent } from "@/components/ui/card";

export function StatsCard({ icon: Icon, title, value, trend }) {
  // Format number with commas (e.g., 1000 -> 1,000)
  const formatNumber = (num) => {
    if (typeof num === "string") {
      // Try to parse if it's a string number
      const parsed = parseInt(num, 10);
      return isNaN(parsed) ? num : parsed.toLocaleString();
    }
    return typeof num === "number" ? num.toLocaleString() : num;
  };

  return (
    <Card className="overflow-hidden border-border/40 bg-card">
      <CardContent className="p-0">
        <div className="flex items-center">
          {/* Icon Section - Left Side */}
          <div className="flex items-center justify-center bg-muted/30 px-6 py-8">
            <Icon className="h-8 w-8 text-muted-foreground" />
          </div>

          {/* Stats Section - Right Side */}
          <div className="flex-1 px-6 py-5">
            <p className="text-sm text-muted-foreground mb-1">{title}</p>
            <div className="flex items-baseline gap-2">
              <p className="text-3xl font-bold tracking-tight">
                {formatNumber(value)}
              </p>
              {trend && (
                <span className="text-xs text-muted-foreground">{trend}</span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
